# AI Math Solver - Replit Development Guide

## Overview

This is a full-stack web application that provides AI-powered mathematical problem solving with step-by-step solutions. The application leverages both Google's Gemini AI and OpenAI's ChatGPT to provide comprehensive solutions, supporting both English and Bengali languages with LaTeX rendering for mathematical expressions.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### January 18, 2025
- ✓ Fixed database connection error by creating PostgreSQL database
- ✓ Successfully pushed database schema with all required tables  
- ✓ Application is now running on port 5000
- ✓ Default admin user created (admin@gmail.com / admin25)
- ✓ Created comprehensive README.md with PostgreSQL setup instructions
- ✓ Created automated install.sh script for VM deployment with:
  - Complete system setup (Node.js, PostgreSQL, Nginx)
  - Database configuration and schema setup
  - Systemd service for auto-start
  - Nginx reverse proxy with security headers
  - Firewall configuration (UFW)
  - Management scripts for easy operation
- ✓ Fixed admin login issue - admin user was inactive, now activated and login works properly
- ✓ Added comprehensive chat history functionality:
  - Moved chat history to separate dedicated page (/history)
  - History button in main interface header for easy access
  - Problems organized by date with beautiful card layout
  - Click to view any previous AI solution in full detail
  - Statistics showing total conversations solved
  - Visual indicators for AI model status (Gemini/ChatGPT)
  - Responsive grid design for optimal viewing

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Math Rendering**: MathJax for LaTeX equation rendering
- **Build Tool**: Vite for development and build processes

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Session Storage**: In-memory storage (fallback to database when needed)
- **API Design**: RESTful endpoints with JSON responses

### Database Schema
- **Primary Table**: `math_problems` storing problem statements, language preferences, and AI solutions
- **Fields**: id, problem text, language (english/bangla), gemini_solution (JSON), chatgpt_solution (JSON), created_at timestamp

## Key Components

### AI Integration Services
- **Gemini Service**: Uses Google's Gemini 2.5 Pro model for mathematical problem solving
- **OpenAI Service**: Uses GPT-4o model for comprehensive step-by-step solutions
- **Dual Processing**: Both AI models process problems concurrently for comparison

### Frontend Components
- **MathInput**: Problem input interface with template suggestions
- **SolutionDisplay**: Renders AI responses with LaTeX support
- **LanguageToggle**: Switches between English and Bengali interfaces
- **ProcessingStatus**: Shows real-time AI processing indicators

### Backend Services
- **Storage Layer**: Abstracts database operations with in-memory fallback
- **Route Handlers**: Process solve requests and manage AI service coordination
- **Error Handling**: Graceful degradation when AI services fail

## Data Flow

1. **Problem Input**: User enters mathematical problem and selects language
2. **AI Processing**: Both Gemini and OpenAI APIs process the problem simultaneously
3. **Response Aggregation**: Solutions are combined and stored in the database
4. **Rendering**: Frontend displays both solutions with MathJax rendering
5. **Storage**: Problem and solutions are persisted for future reference

## External Dependencies

### AI Services
- **Google Gemini API**: Requires `GEMINI_API_KEY` environment variable
- **OpenAI API**: Requires `OPENAI_API_KEY` environment variable
- **Model Versions**: Gemini 2.5 Pro and GPT-4o (latest stable versions)

### Database
- **PostgreSQL**: Required for persistent storage
- **Neon Database**: Serverless PostgreSQL provider integration
- **Connection**: Uses `DATABASE_URL` environment variable

### Frontend Libraries
- **MathJax**: CDN-loaded for mathematical equation rendering
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite dev server with Express backend
- **Hot Reload**: Full-stack hot module replacement
- **Database**: Local PostgreSQL or Neon development database

### Production Build
- **Frontend**: Vite builds optimized React bundle
- **Backend**: esbuild creates Node.js bundle
- **Static Assets**: Served from Express with appropriate caching headers

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `GEMINI_API_KEY`: Google AI API key
- `OPENAI_API_KEY`: OpenAI API key
- `NODE_ENV`: Environment mode (development/production)

### Database Migrations
- **Drizzle Kit**: Manages schema migrations
- **Push Command**: `npm run db:push` applies schema changes
- **Schema Location**: `shared/schema.ts` contains table definitions

## Architecture Decisions

### Why Dual AI Processing?
- **Problem**: Different AI models excel at different types of mathematical problems
- **Solution**: Process with both Gemini and OpenAI concurrently
- **Benefits**: Users get multiple perspectives and can compare approaches
- **Trade-offs**: Higher API costs but better solution quality

### Why In-Memory Storage Fallback?
- **Problem**: Database connection might fail during development
- **Solution**: MemStorage class provides in-memory persistence
- **Benefits**: Application remains functional without database
- **Trade-offs**: Data is lost on server restart

### Why MathJax Over KaTeX?
- **Problem**: Complex mathematical expressions need robust rendering
- **Solution**: MathJax provides comprehensive LaTeX support
- **Benefits**: Handles advanced mathematics and multiple input formats
- **Trade-offs**: Slightly larger bundle size but better compatibility

### Why Drizzle ORM?
- **Problem**: Type-safe database operations with PostgreSQL
- **Solution**: Drizzle provides TypeScript-first ORM with great PostgreSQL support
- **Benefits**: Excellent type inference and migration management
- **Trade-offs**: Learning curve compared to raw SQL