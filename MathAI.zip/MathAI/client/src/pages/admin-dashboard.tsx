import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertAnnouncementSchema } from '@shared/schema';
import { 
  Users, 
  MessageSquare, 
  BarChart3, 
  Settings, 
  Plus, 
  Edit, 
  Trash2,
  Shield,
  CheckCircle,
  XCircle,
  Eye,
  EyeOff
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'problems' | 'announcements'>('overview');
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<any>(null);

  // Redirect if not admin
  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-bg-light flex items-center justify-center">
        <Card className="w-full max-w-md bg-card-white">
          <CardContent className="p-6 text-center">
            <Shield className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-text-dark mb-2">Access Denied</h2>
            <p className="text-gray-600 mb-4">You need admin privileges to access this page.</p>
            <Link href="/">
              <Button>Go Back to Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Queries
  const { data: analytics } = useQuery({
    queryKey: ['/api/admin/analytics'],
  });

  const { data: users = [] } = useQuery({
    queryKey: ['/api/admin/users'],
  });

  const { data: problems = [] } = useQuery({
    queryKey: ['/api/admin/problems'],
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ['/api/admin/announcements'],
  });

  // Mutations
  const updateUserMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      const response = await apiRequest('PATCH', `/api/admin/users/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({ title: 'User updated successfully' });
    },
  });

  const createAnnouncementMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/admin/announcements', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/announcements'] });
      queryClient.invalidateQueries({ queryKey: ['/api/announcements'] });
      toast({ title: 'Announcement created successfully' });
      setShowAnnouncementForm(false);
      form.reset();
    },
  });

  const updateAnnouncementMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      const response = await apiRequest('PATCH', `/api/admin/announcements/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/announcements'] });
      queryClient.invalidateQueries({ queryKey: ['/api/announcements'] });
      toast({ title: 'Announcement updated successfully' });
      setEditingAnnouncement(null);
    },
  });

  const deleteAnnouncementMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/admin/announcements/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/announcements'] });
      queryClient.invalidateQueries({ queryKey: ['/api/announcements'] });
      toast({ title: 'Announcement deleted successfully' });
    },
  });

  // Form
  const form = useForm({
    resolver: zodResolver(insertAnnouncementSchema),
    defaultValues: {
      title: '',
      content: '',
      type: 'info',
      isActive: true,
    },
  });

  const onSubmitAnnouncement = async (data: any) => {
    if (editingAnnouncement) {
      updateAnnouncementMutation.mutate({ id: editingAnnouncement.id, updates: data });
    } else {
      createAnnouncementMutation.mutate(data);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'problems', label: 'Problems', icon: MessageSquare },
    { id: 'announcements', label: 'Announcements', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-bg-light">
      {/* Header */}
      <header className="bg-card-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  ← Back to App
                </Button>
              </Link>
              <h1 className="text-xl font-inter font-semibold text-text-dark">
                Admin Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              <Shield className="w-5 h-5 text-google-blue" />
              <span className="text-sm font-medium text-text-dark">
                {user.name}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  logout();
                  toast({ title: 'Logged out successfully' });
                }}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex space-x-1 mb-8 bg-gray-100 rounded-lg p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-card-white text-google-blue shadow-sm'
                  : 'text-gray-600 hover:text-text-dark'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-gray-600">Total Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-text-dark">
                  {analytics?.totalUsers || 0}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-gray-600">Total Problems</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-text-dark">
                  {analytics?.totalProblems || 0}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-gray-600">Daily Problems</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-text-dark">
                  {analytics?.dailyProblems || 0}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-gray-600">Active Users Today</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-text-dark">
                  {analytics?.activeUsers || 0}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>
                  View and manage all registered users
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user: any) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex-1">
                          <h3 className="font-medium text-text-dark">{user.name}</h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">
                            Joined: {new Date(user.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                            {user.role}
                          </Badge>
                          <Badge variant={user.isActive ? 'default' : 'destructive'}>
                            {user.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateUserMutation.mutate({ 
                            id: user.id, 
                            updates: { isActive: !user.isActive } 
                          })}
                        >
                          {user.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </Button>
                        <Select
                          value={user.role}
                          onValueChange={(role) => updateUserMutation.mutate({ 
                            id: user.id, 
                            updates: { role } 
                          })}
                        >
                          <SelectTrigger className="w-20">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">User</SelectItem>
                            <SelectItem value="admin">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Problems Tab */}
        {activeTab === 'problems' && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Problem History</CardTitle>
                <CardDescription>
                  View all math problems submitted by users
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {problems.map((problem: any) => (
                    <div key={problem.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-medium text-text-dark">{problem.problem}</p>
                          <div className="flex items-center space-x-4 mt-2">
                            <Badge variant="outline">{problem.language}</Badge>
                            <span className="text-sm text-gray-600">
                              {new Date(problem.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {problem.geminiSolution && (
                            <Badge variant="default">Gemini</Badge>
                          )}
                          {problem.chatgptSolution && (
                            <Badge variant="secondary">ChatGPT</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Announcements Tab */}
        {activeTab === 'announcements' && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Announcements
                  <Button
                    onClick={() => setShowAnnouncementForm(true)}
                    className="bg-google-blue hover:bg-blue-600"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Announcement
                  </Button>
                </CardTitle>
                <CardDescription>
                  Manage announcements shown to users
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Announcement Form */}
                {(showAnnouncementForm || editingAnnouncement) && (
                  <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                    <h3 className="font-medium text-text-dark mb-4">
                      {editingAnnouncement ? 'Edit Announcement' : 'Create New Announcement'}
                    </h3>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmitAnnouncement)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Title</FormLabel>
                              <FormControl>
                                <Input placeholder="Announcement title" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="content"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Content</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Announcement content" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Type</FormLabel>
                              <Select value={field.value} onValueChange={field.onChange}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="info">Info</SelectItem>
                                  <SelectItem value="success">Success</SelectItem>
                                  <SelectItem value="warning">Warning</SelectItem>
                                  <SelectItem value="error">Error</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex space-x-2">
                          <Button type="submit" className="bg-google-blue hover:bg-blue-600">
                            {editingAnnouncement ? 'Update' : 'Create'}
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              setShowAnnouncementForm(false);
                              setEditingAnnouncement(null);
                              form.reset();
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                )}

                {/* Announcements List */}
                <div className="space-y-4">
                  {announcements.map((announcement: any) => (
                    <div key={announcement.id} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-medium text-text-dark">{announcement.title}</h3>
                            <Badge variant={announcement.type === 'info' ? 'default' : 'secondary'}>
                              {announcement.type}
                            </Badge>
                            {announcement.isActive ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-500" />
                            )}
                          </div>
                          <p className="text-gray-600 mb-2">{announcement.content}</p>
                          <p className="text-xs text-gray-500">
                            Created: {new Date(announcement.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => updateAnnouncementMutation.mutate({
                              id: announcement.id,
                              updates: { isActive: !announcement.isActive }
                            })}
                          >
                            {announcement.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setEditingAnnouncement(announcement);
                              form.setValue('title', announcement.title);
                              form.setValue('content', announcement.content);
                              form.setValue('type', announcement.type);
                              form.setValue('isActive', announcement.isActive);
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteAnnouncementMutation.mutate(announcement.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}