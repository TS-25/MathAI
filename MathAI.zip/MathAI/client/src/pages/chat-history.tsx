import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { 
  History, 
  MessageSquare, 
  Clock, 
  ArrowLeft,
  CalendarDays,
  Sparkles,
  Eye,
  Calculator
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'wouter';
import { SolutionDisplay } from '@/components/solution-display';

interface MathProblem {
  id: number;
  problem: string;
  language: string;
  geminiSolution: any;
  chatgptSolution: any;
  createdAt: string;
}

export default function ChatHistoryPage() {
  const { user } = useAuth();
  const [selectedProblem, setSelectedProblem] = useState<MathProblem | null>(null);

  const { data: problems = [], isLoading } = useQuery<MathProblem[]>({
    queryKey: ['/api/problems'],
    enabled: !!user,
  });

  // Group problems by date
  const groupedProblems = problems.reduce((groups, problem) => {
    const date = new Date(problem.createdAt).toDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(problem);
    return groups;
  }, {} as Record<string, MathProblem[]>);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toDateString();
    
    if (date.toDateString() === today) return "Today";
    if (date.toDateString() === yesterday) return "Yesterday";
    return date.toLocaleDateString();
  };

  const truncateText = (text: string, maxLength: number = 100) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  if (selectedProblem) {
    return (
      <div className="min-h-screen bg-bg-light">
        {/* Header */}
        <header className="bg-card-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  onClick={() => setSelectedProblem(null)}
                  className="mr-3"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to History
                </Button>
                <div className="w-10 h-10 bg-google-blue rounded-lg flex items-center justify-center">
                  <Calculator className="text-white w-5 h-5" />
                </div>
                <div>
                  <h1 className="text-xl font-inter font-semibold text-text-dark">
                    Previous Solution
                  </h1>
                  <p className="text-sm text-gray-600">
                    {new Date(selectedProblem.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
              <Link href="/">
                <Button variant="outline">
                  Back to Solver
                </Button>
              </Link>
            </div>
          </div>
        </header>

        {/* Solution Display */}
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <SolutionDisplay
            problem={selectedProblem.problem}
            geminiResponse={selectedProblem.geminiSolution}
            openaiResponse={selectedProblem.chatgptSolution}
          />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-light">
      {/* Header */}
      <header className="bg-card-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-google-blue rounded-lg flex items-center justify-center">
                <History className="text-white w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-inter font-semibold text-text-dark">
                  Chat History
                </h1>
                <p className="text-sm text-gray-600">
                  View your previous AI conversations
                </p>
              </div>
            </div>
            <Link href="/">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Solver
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                  <div className="h-3 bg-gray-100 rounded w-1/2 mb-2"></div>
                  <div className="h-3 bg-gray-100 rounded w-1/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : problems.length === 0 ? (
          <div className="text-center py-16">
            <MessageSquare className="w-24 h-24 text-gray-300 mx-auto mb-6" />
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">
              No Chat History
            </h2>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              You haven't solved any math problems yet. Start by going back to the solver and asking your first question!
            </p>
            <Link href="/">
              <Button className="bg-google-blue hover:bg-blue-600">
                <Calculator className="w-4 h-4 mr-2" />
                Start Solving
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Statistics */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Sparkles className="w-8 h-8 text-google-blue" />
                    <div>
                      <h3 className="text-lg font-semibold text-text-dark">
                        Total Conversations
                      </h3>
                      <p className="text-gray-600">
                        You've solved {problems.length} problem{problems.length !== 1 ? 's' : ''} so far
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-google-blue">
                      {problems.length}
                    </div>
                    <div className="text-sm text-gray-600">Problems</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* History by Date */}
            {Object.entries(groupedProblems)
              .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
              .map(([date, dateProblems]) => (
                <div key={date}>
                  {/* Date Header */}
                  <div className="flex items-center space-x-3 mb-4">
                    <CalendarDays className="w-5 h-5 text-gray-400" />
                    <h2 className="text-lg font-semibold text-text-dark">
                      {formatDate(date)}
                    </h2>
                    <Badge variant="secondary">
                      {dateProblems.length} problem{dateProblems.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>

                  {/* Problems Grid */}
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-8">
                    {dateProblems
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((problem) => (
                        <Card
                          key={problem.id}
                          className="cursor-pointer transition-all hover:shadow-lg hover:scale-105 border-gray-200 hover:border-google-blue"
                          onClick={() => setSelectedProblem(problem)}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <Badge 
                                  variant="secondary" 
                                  className="text-xs mb-2"
                                >
                                  {problem.language === 'bangla' ? 'বাংলা' : 'English'}
                                </Badge>
                                <CardTitle className="text-sm font-medium leading-relaxed">
                                  {truncateText(problem.problem)}
                                </CardTitle>
                              </div>
                            </div>
                          </CardHeader>
                          
                          <CardContent className="pt-0">
                            <div className="flex items-center justify-between">
                              {/* AI Status */}
                              <div className="flex items-center space-x-2">
                                <div className="flex space-x-1">
                                  {problem.geminiSolution && (
                                    <div 
                                      className="w-3 h-3 bg-green-500 rounded-full" 
                                      title="Gemini solved" 
                                    />
                                  )}
                                  {problem.chatgptSolution && (
                                    <div 
                                      className="w-3 h-3 bg-blue-500 rounded-full" 
                                      title="ChatGPT solved" 
                                    />
                                  )}
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 px-2 text-xs text-google-blue hover:bg-blue-50"
                                >
                                  <Eye className="w-3 h-3 mr-1" />
                                  View
                                </Button>
                              </div>

                              {/* Time */}
                              <div className="flex items-center space-x-1 text-xs text-gray-500">
                                <Clock className="w-3 h-3" />
                                <span>
                                  {formatDistanceToNow(new Date(problem.createdAt), { addSuffix: true })}
                                </span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              ))}
          </div>
        )}
      </main>
    </div>
  );
}