import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { LanguageToggle } from "@/components/language-toggle";
import { MathInput } from "@/components/math-input";
import { ProcessingStatus } from "@/components/processing-status";
import { SolutionDisplay } from "@/components/solution-display";
import { AnnouncementBar } from "@/components/announcement-bar";
import { Calculator, LogOut, Settings, User, BarChart3, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface SolveResponse {
  problem: string;
  language: string;
  gemini: any;
  openai: any;
}

export default function MathSolver() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [language, setLanguage] = useState<"english" | "bangla">("english");
  const [currentSolution, setCurrentSolution] = useState<SolveResponse | null>(null);

  // Get daily usage
  const { data: dailyUsage } = useQuery({
    queryKey: ['/api/usage/daily'],
    enabled: !!user,
  });

  const solveMutation = useMutation({
    mutationFn: async (data: { problem: string; language: string }) => {
      const response = await apiRequest("POST", "/api/solve", data);
      return response.json();
    },
    onSuccess: (data: SolveResponse) => {
      setCurrentSolution(data);
      // Invalidate queries to update count and history
      queryClient.invalidateQueries({ queryKey: ['/api/usage/daily'] });
      queryClient.invalidateQueries({ queryKey: ['/api/problems'] });
      toast({
        title: "Problem solved!",
        description: `${dailyUsage?.remaining - 1 || 0} problems remaining today.`,
      });
    },
    onError: (error: Error) => {
      console.error("Solve error:", error);
      if (error.message.includes('429')) {
        toast({
          title: "Daily limit reached",
          description: "You've solved 10 problems today. Come back tomorrow!",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Failed to solve problem",
          description: error.message || "Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleSolve = (problem: string) => {
    solveMutation.mutate({ problem, language });
  };

  const handleLanguageChange = (newLanguage: "english" | "bangla") => {
    setLanguage(newLanguage);
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Signed out",
      description: "You have been signed out successfully.",
    });
  };

  return (
    <div className="min-h-screen bg-bg-light flex flex-col">
      {/* Header */}
      <header className="bg-card-white shadow-sm border-b border-gray-200 flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-google-blue rounded-lg flex items-center justify-center">
                <Calculator className="text-white w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-inter font-semibold text-text-dark">
                  SRJ MATH AI
                </h1>
                <p className="text-sm text-gray-600">
                  Powered by SRJ MATH AI 1 & SRJ MATH AI 2
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <LanguageToggle 
                currentLanguage={language} 
                onLanguageChange={handleLanguageChange} 
              />

              {user && (
                <div className="flex items-center space-x-3">
                  {/* Chat History Button */}
                  <Link href="/history">
                    <Button variant="outline" size="sm">
                      <History className="w-4 h-4 mr-2" />
                      History
                    </Button>
                  </Link>

                  {/* Daily Usage */}
                  <Card className="px-3 py-2">
                    <div className="flex items-center space-x-2">
                      <BarChart3 className="w-4 h-4 text-google-blue" />
                      <div className="text-sm">
                        <span className="font-medium">
                          {dailyUsage?.remaining || 0}
                        </span>
                        <span className="text-gray-600"> / 10 left</span>
                      </div>
                    </div>
                  </Card>

                  {/* User Menu */}
                  <div className="flex items-center space-x-2">
                    <div className="text-sm">
                      <p className="font-medium text-text-dark">{user.name}</p>
                      <p className="text-gray-600">{user.email}</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {user.role === 'admin' && (
                        <Link href="/admin">
                          <Button variant="ghost" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                        </Link>
                      )}
                      <Button variant="ghost" size="sm" onClick={handleLogout}>
                        <LogOut className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Announcement Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <AnnouncementBar />
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MathInput 
          onSolve={handleSolve} 
          isLoading={solveMutation.isPending} 
        />

        {solveMutation.isPending && <ProcessingStatus />}

        {currentSolution && (
          <SolutionDisplay
            problem={currentSolution.problem}
            geminiResponse={currentSolution.gemini}
            openaiResponse={currentSolution.openai}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-card-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-google-blue rounded-lg flex items-center justify-center">
                  <Calculator className="text-white w-4 h-4" />
                </div>
                <h4 className="font-inter font-semibold text-text-dark">
                  AI Math Solver
                </h4>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Powered by advanced AI models to provide accurate, step-by-step solutions to mathematical problems in multiple languages.
              </p>
            </div>
            <div>
              <h5 className="font-medium text-text-dark mb-3">Features</h5>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>Step-by-step solutions</li>
                <li>Multi-language support</li>
                <li>LaTeX equation input</li>
                <li>AI comparison</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-text-dark mb-3">Support</h5>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>Help Center</li>
                <li>Contact Support</li>
                <li>Report Issues</li>
                <li>Feature Requests</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-8 pt-8 text-center text-sm text-gray-600">
            <p>&copy; 2024 SRJ MATH AI. Powered by SRJ MATH AI 1 and SRJ MATH AI 2 APIs.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}