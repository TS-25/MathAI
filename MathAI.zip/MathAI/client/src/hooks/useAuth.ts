import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { User, LoginRequest, RegisterRequest } from '@shared/schema';

export function useAuth() {
  const [isInitialized, setIsInitialized] = useState(false);
  const queryClient = useQueryClient();

  // Get current user
  const { data: user, isLoading: isUserLoading } = useQuery<User>({
    queryKey: ['/api/auth/me'],
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    enabled: !!localStorage.getItem('token'), // Only run query if token exists
    queryFn: async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('No token found');
      }
      const response = await apiRequest('GET', '/api/auth/me');
      if (!response.ok) {
        localStorage.removeItem('token'); // Remove invalid token
        throw new Error('Authentication failed');
      }
      return response.json();
    },
  });

  // Initialize auth state
  useEffect(() => {
    if (!isInitialized && !isUserLoading) {
      setIsInitialized(true);
    }
  }, [isUserLoading, isInitialized]);

  const login = async (email: string, password: string) => {
    const response = await apiRequest('POST', '/api/auth/login', { email, password });
    const data = await response.json();
    
    if (data.token) {
      localStorage.setItem('token', data.token);
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      return data;
    }
    
    throw new Error(data.message || 'Login failed');
  };

  const register = async (name: string, email: string, password: string) => {
    const response = await apiRequest('POST', '/api/auth/register', { name, email, password });
    const data = await response.json();
    
    if (data.token) {
      localStorage.setItem('token', data.token);
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      return data;
    }
    
    throw new Error(data.message || 'Registration failed');
  };

  const logout = () => {
    localStorage.removeItem('token');
    queryClient.setQueryData(['/api/auth/me'], null);
    queryClient.invalidateQueries();
  };

  return {
    user,
    isLoading: !isInitialized || isUserLoading,
    login,
    register,
    logout,
    isAuthenticated: !!user,
  };
}