import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export function ProcessingStatus() {
  return (
    <div className="max-w-4xl mx-auto mb-8">
      <Card className="bg-card-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-center space-x-8">
            <div className="flex items-center space-x-3">
              <Loader2 className="w-8 h-8 animate-spin text-google-blue" />
              <div>
                <p className="font-medium text-text-dark">Gemini AI</p>
                <p className="text-sm text-gray-600">Processing...</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Loader2 className="w-8 h-8 animate-spin text-success-green" />
              <div>
                <p className="font-medium text-text-dark">ChatGPT</p>
                <p className="text-sm text-gray-600">Processing...</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
