import { useQuery } from '@tanstack/react-query';
import { X, AlertCircle, Info, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { Announcement } from '@shared/schema';

export function AnnouncementBar() {
  const [dismissed, setDismissed] = useState<Set<number>>(new Set());

  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ['/api/announcements'],
    staleTime: 60 * 1000, // 1 minute
  });

  const activeAnnouncements = announcements.filter(
    (announcement) => !dismissed.has(announcement.id)
  );

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-4 h-4" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4" />;
      case 'error':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const getColors = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'error':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const handleDismiss = (id: number) => {
    setDismissed(prev => new Set(prev).add(id));
  };

  if (activeAnnouncements.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2">
      {activeAnnouncements.map((announcement) => (
        <div
          key={announcement.id}
          className={`border rounded-lg p-3 ${getColors(announcement.type)}`}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <div className="mt-0.5">
                {getIcon(announcement.type)}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-sm">{announcement.title}</h4>
                <p className="text-sm mt-1">{announcement.content}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleDismiss(announcement.id)}
              className="h-6 w-6 p-0 hover:bg-transparent"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}