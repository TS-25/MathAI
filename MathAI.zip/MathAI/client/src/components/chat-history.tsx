import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { 
  History, 
  MessageSquare, 
  Clock, 
  ChevronRight,
  CalendarDays,
  Sparkles
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface MathProblem {
  id: number;
  problem: string;
  language: string;
  geminiSolution: any;
  chatgptSolution: any;
  createdAt: string;
}

interface ChatHistoryProps {
  onProblemSelect: (problem: MathProblem) => void;
  selectedProblemId?: number;
}

export function ChatHistory({ onProblemSelect, selectedProblemId }: ChatHistoryProps) {
  const { user } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const { data: problems = [], isLoading } = useQuery<MathProblem[]>({
    queryKey: ['/api/problems'],
    enabled: !!user,
  });

  // Group problems by date
  const groupedProblems = problems.reduce((groups, problem) => {
    const date = new Date(problem.createdAt).toDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(problem);
    return groups;
  }, {} as Record<string, MathProblem[]>);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toDateString();
    
    if (date.toDateString() === today) return "Today";
    if (date.toDateString() === yesterday) return "Yesterday";
    return date.toLocaleDateString();
  };

  const truncateText = (text: string, maxLength: number = 50) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card-white border-r border-gray-200 flex flex-col items-center py-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(false)}
          className="mb-4"
        >
          <History className="w-5 h-5" />
        </Button>
        <div className="writing-vertical-rl text-sm text-gray-600 transform rotate-180">
          History
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <div className="flex items-center space-x-2">
          <History className="w-5 h-5 text-google-blue" />
          <h2 className="font-inter font-semibold text-text-dark">Chat History</h2>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(true)}
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-4 space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-100 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : problems.length === 0 ? (
          <div className="p-6 text-center">
            <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">
              No chat history yet.<br />
              Start by solving your first math problem!
            </p>
          </div>
        ) : (
          <div className="p-2">
            {Object.entries(groupedProblems)
              .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
              .map(([date, dateProblems]) => (
                <div key={date} className="mb-4">
                  {/* Date Header */}
                  <div className="flex items-center space-x-2 px-2 py-1 mb-2">
                    <CalendarDays className="w-3 h-3 text-gray-400" />
                    <span className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                      {formatDate(date)}
                    </span>
                  </div>

                  {/* Problems for this date */}
                  <div className="space-y-1">
                    {dateProblems
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((problem) => (
                        <Card
                          key={problem.id}
                          className={`cursor-pointer transition-all hover:shadow-md border ${
                            selectedProblemId === problem.id
                              ? 'border-google-blue bg-blue-50'
                              : 'border-gray-100 hover:border-gray-200'
                          }`}
                          onClick={() => onProblemSelect(problem)}
                        >
                          <CardContent className="p-3">
                            <div className="space-y-2">
                              {/* Problem text */}
                              <p className="text-sm text-text-dark font-medium leading-relaxed">
                                {truncateText(problem.problem)}
                              </p>

                              {/* Metadata */}
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <Badge 
                                    variant="secondary" 
                                    className="text-xs"
                                  >
                                    {problem.language === 'bangla' ? 'বাংলা' : 'English'}
                                  </Badge>
                                  
                                  {/* AI status indicators */}
                                  <div className="flex space-x-1">
                                    {problem.geminiSolution && (
                                      <div className="w-2 h-2 bg-green-500 rounded-full" title="Gemini solved" />
                                    )}
                                    {problem.chatgptSolution && (
                                      <div className="w-2 h-2 bg-blue-500 rounded-full" title="ChatGPT solved" />
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center space-x-1 text-xs text-gray-500">
                                  <Clock className="w-3 h-3" />
                                  <span>
                                    {formatDistanceToNow(new Date(problem.createdAt), { addSuffix: true })}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              ))}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      {problems.length > 0 && (
        <div className="p-3 border-t border-gray-100 bg-gray-50">
          <div className="flex items-center justify-center space-x-2 text-xs text-gray-600">
            <Sparkles className="w-3 h-3" />
            <span>{problems.length} conversation{problems.length !== 1 ? 's' : ''} total</span>
          </div>
        </div>
      )}
    </div>
  );
}