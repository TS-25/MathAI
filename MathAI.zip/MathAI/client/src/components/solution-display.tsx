import { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MathSolution {
  steps: Array<{
    title: string;
    description: string;
    equation?: string;
    type: "method" | "formula" | "calculation" | "solution";
  }>;
  finalAnswer: string;
  approach: string;
  explanation: string;
}

interface AIResponse {
  solution?: MathSolution;
  processingTime?: number;
  model?: string;
  error?: string;
}

interface SolutionDisplayProps {
  problem: string;
  geminiResponse: AIResponse;
  openaiResponse: AIResponse;
}

export function SolutionDisplay({ problem, geminiResponse, openaiResponse }: SolutionDisplayProps) {
  const { toast } = useToast();

  useEffect(() => {
    // Re-render MathJax when solutions change
    if (window.MathJax) {
      window.MathJax.typesetPromise();
    }
  }, [problem, geminiResponse, openaiResponse]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Solution copied to clipboard",
    });
  };

  const getStepTypeColor = (type: string) => {
    switch (type) {
      case "method": return "bg-blue-100 text-blue-800";
      case "formula": return "bg-green-100 text-green-800";
      case "calculation": return "bg-yellow-100 text-yellow-800";
      case "solution": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const renderSolution = (response: AIResponse, title: string, icon: React.ReactNode, borderColor: string) => (
    <Card className="bg-card-white shadow-lg">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${borderColor}`}>
              {icon}
            </div>
            <div>
              <h4 className="font-inter font-semibold text-text-dark">{title}</h4>
              <p className="text-sm text-gray-600">
                {response.error ? "Error occurred" : "Step-by-step explanation"}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => copyToClipboard(JSON.stringify(response, null, 2))}
            className="text-gray-500 hover:text-gray-700"
          >
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      <CardContent className="p-6">
        {response.error ? (
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="w-5 h-5" />
            <p>{response.error}</p>
          </div>
        ) : response.solution ? (
          <div className="space-y-4">
            {response.solution.steps.map((step, index) => (
              <div key={index} className={`border-l-4 pl-4 math-step ${borderColor.replace('bg-', 'border-')}`}>
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium text-text-dark">{step.title}</h5>
                  <Badge variant="secondary" className={getStepTypeColor(step.type)}>
                    {step.type}
                  </Badge>
                </div>
                <p className="text-gray-700 mb-3">{step.description}</p>
                {step.equation && (
                  <div className="math-equation font-jetbrains">
                    {step.equation}
                  </div>
                )}
              </div>
            ))}

            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <h5 className="font-medium text-success-green mb-2 flex items-center">
                <CheckCircle className="w-5 h-5 mr-2" />
                Final Answer:
              </h5>
              <div className="font-jetbrains text-lg">
                {response.solution.finalAnswer}
              </div>
            </div>

            {response.processingTime && (
              <p className="text-sm text-gray-500">
                Processing time: {response.processingTime}ms
              </p>
            )}
          </div>
        ) : (
          <p className="text-gray-500">No solution available</p>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Problem Display */}
      <Card className="bg-card-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-inter font-semibold text-text-dark">Problem:</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => copyToClipboard(problem)}
              className="text-gray-500 hover:text-gray-700"
            >
              <Copy className="w-4 h-4" />
            </Button>
          </div>
          <div className="bg-gray-50 rounded-xl p-4 font-jetbrains text-lg">
            {problem}
          </div>
        </CardContent>
      </Card>

      {/* AI Solutions Comparison */}
      <div className="grid lg:grid-cols-2 gap-6">
        {renderSolution(
          geminiResponse,
          "SRJ MATH AI 1 Solution",
          <div className="text-white text-sm">1</div>,
          "bg-google-blue"
        )}
        {renderSolution(
          openaiResponse,
          "SRJ MATH AI 2 Solution",
          <div className="text-white text-sm">2</div>,
          "bg-success-green"
        )}
      </div>

      {/* Solution Comparison */}
      {geminiResponse.solution && openaiResponse.solution && (
        <Card className="bg-card-white shadow-lg">
          <CardContent className="p-6">
            <h4 className="font-inter font-semibold text-text-dark mb-4 flex items-center">
              <div className="w-6 h-6 mr-2">⚖️</div>
              Solution Comparison
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h5 className="font-medium text-text-dark">SRJ MATH AI 1 Approach</h5>
                <p className="text-sm text-gray-700">{geminiResponse.solution.approach}</p>
                <p className="text-sm text-gray-600">{geminiResponse.solution.explanation}</p>
              </div>
              <div className="space-y-3">
                <h5 className="font-medium text-text-dark">SRJ MATH AI 2 Approach</h5>
                <p className="text-sm text-gray-700">{openaiResponse.solution.approach}</p>
                <p className="text-sm text-gray-600">{openaiResponse.solution.explanation}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
