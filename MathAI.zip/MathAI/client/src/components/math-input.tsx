import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, SquareRadical, Infinity, Calculator, Grid3x3 } from "lucide-react";

interface MathInputProps {
  onSolve: (problem: string) => void;
  isLoading: boolean;
}

export function MathInput({ onSolve, isLoading }: MathInputProps) {
  const [problem, setProblem] = useState("");

  const handleSolve = () => {
    const trimmedProblem = problem.trim();
    if (!trimmedProblem) {
      alert("Please enter a math problem first!");
      return;
    }
    onSolve(trimmedProblem);
  };

  const insertTemplate = (template: string) => {
    setProblem(prev => prev + template);
  };

  const examples = [
    { category: "Algebra", problem: "3x + 7 = 22" },
    { category: "Calculus", problem: "∫ x² dx" },
    { category: "Geometry", problem: "Area of circle r=5" },
  ];

  return (
    <div className="space-y-8">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-card-white shadow-lg">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-inter font-semibold text-text-dark mb-2">
                Solve Any Math Problem
              </h2>
              <p className="text-gray-600">
                Enter your mathematical problem and get step-by-step solutions in your preferred language
              </p>
            </div>

            <div className="space-y-4">
              <div className="relative">
                <Textarea
                  value={problem}
                  onChange={(e) => setProblem(e.target.value)}
                  className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-google-blue focus:outline-none resize-none font-jetbrains text-lg"
                  rows={4}
                  placeholder="Enter your math problem here... (e.g., Solve: 2x + 3 = 7, or integrate x^2 dx)"
                />
                <div className="absolute bottom-3 right-3 text-sm text-gray-500">
                  <Calculator className="w-4 h-4 inline mr-1" />
                  LaTeX supported
                </div>
              </div>

              <div className="flex flex-wrap gap-2 justify-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => insertTemplate("\\sqrt{}")}
                  className="px-3 py-1 bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  <SquareRadical className="w-4 h-4 mr-1" />
                  Square Root
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => insertTemplate("\\int {} dx")}
                  className="px-3 py-1 bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  <Infinity className="w-4 h-4 mr-1" />
                  Infinity
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => insertTemplate("\\frac{}{}")}
                  className="px-3 py-1 bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  <Calculator className="w-4 h-4 mr-1" />
                  Fraction
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => insertTemplate("\\begin{matrix} & \\\\ & \\end{matrix}")}
                  className="px-3 py-1 bg-gray-100 text-gray-700 hover:bg-gray-200"
                >
                  <Grid3x3 className="w-4 h-4 mr-1" />
                  Matrix
                </Button>
              </div>

              <div className="flex justify-center">
                <Button
                  onClick={handleSolve}
                  disabled={isLoading}
                  className="px-8 py-3 bg-google-blue text-white rounded-xl font-medium hover:bg-blue-600 transition-colors flex items-center space-x-2"
                >
                  <Brain className="w-5 h-5" />
                  <span>{isLoading ? "Solving..." : "Solve with AI"}</span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="max-w-4xl mx-auto">
        <h3 className="text-xl font-inter font-semibold text-text-dark mb-6 text-center">
          Try These Examples
        </h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {examples.map((example, index) => (
            <Button
              key={index}
              variant="ghost"
              onClick={() => setProblem(example.problem)}
              className="bg-card-white rounded-xl p-4 text-left hover:shadow-md transition-shadow h-auto"
            >
              <div className="font-jetbrains text-sm mb-2 text-google-blue">
                {example.category}
              </div>
              <div className="font-jetbrains text-sm">
                {example.problem}
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
