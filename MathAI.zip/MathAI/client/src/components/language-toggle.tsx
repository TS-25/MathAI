import { Button } from "@/components/ui/button";

interface LanguageToggleProps {
  currentLanguage: string;
  onLanguageChange: (language: "english" | "bangla") => void;
}

export function LanguageToggle({ currentLanguage, onLanguageChange }: LanguageToggleProps) {
  return (
    <div className="flex items-center space-x-4">
      <div className="bg-gray-100 p-1 rounded-lg flex">
        <Button
          variant={currentLanguage === "english" ? "default" : "ghost"}
          size="sm"
          onClick={() => onLanguageChange("english")}
          className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
            currentLanguage === "english"
              ? "bg-google-blue text-white"
              : "text-gray-700 hover:text-gray-900"
          }`}
        >
          English
        </Button>
        <Button
          variant={currentLanguage === "bangla" ? "default" : "ghost"}
          size="sm"
          onClick={() => onLanguageChange("bangla")}
          className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
            currentLanguage === "bangla"
              ? "bg-google-blue text-white"
              : "text-gray-700 hover:text-gray-900"
          }`}
        >
          বাংলা
        </Button>
      </div>
    </div>
  );
}
