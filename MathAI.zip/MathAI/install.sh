#!/bin/bash

# AI Math Solver - Automated Installation Script
# This script installs and configures the AI Math Solver on a fresh VM
# Supports Ubuntu 20.04+ and Debian-based systems

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "This script should not be run as root. Please run as a regular user with sudo privileges."
        exit 1
    fi
}

# Check OS compatibility
check_os() {
    if [[ "$OSTYPE" != "linux-gnu"* ]]; then
        log_error "This script is designed for Linux systems only."
        exit 1
    fi
    
    if ! command -v apt-get &> /dev/null; then
        log_error "This script requires apt-get (Debian/Ubuntu based system)."
        exit 1
    fi
}

# Update system packages
update_system() {
    log_info "Updating system packages..."
    sudo apt-get update
    sudo apt-get upgrade -y
    log_success "System packages updated"
}

# Install Node.js 20
install_nodejs() {
    log_info "Installing Node.js 20..."
    
    # Remove existing Node.js installations
    sudo apt-get remove -y nodejs npm 2>/dev/null || true
    
    # Install Node.js 20 using NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    
    # Verify installation
    node_version=$(node --version)
    npm_version=$(npm --version)
    log_success "Node.js $node_version and npm $npm_version installed"
}

# Install PostgreSQL
install_postgresql() {
    log_info "Installing PostgreSQL..."
    
    sudo apt-get install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
    
    log_success "PostgreSQL installed and started"
}

# Setup PostgreSQL database
setup_database() {
    log_info "Setting up database..."
    
    # Create database and user
    sudo -u postgres psql <<EOF
CREATE DATABASE ai_math_solver;
CREATE USER mathsolver WITH PASSWORD 'mathsolver123';
GRANT ALL PRIVILEGES ON DATABASE ai_math_solver TO mathsolver;
ALTER USER mathsolver CREATEDB;
\q
EOF
    
    log_success "Database 'ai_math_solver' created with user 'mathsolver'"
}

# Install additional dependencies
install_dependencies() {
    log_info "Installing system dependencies..."
    
    sudo apt-get install -y \
        git \
        curl \
        wget \
        unzip \
        build-essential \
        python3 \
        python3-pip \
        nginx \
        certbot \
        python3-certbot-nginx
    
    log_success "System dependencies installed"
}

# Clone and setup application
setup_application() {
    log_info "Setting up AI Math Solver application..."
    
    # Create application directory
    APP_DIR="/opt/ai-math-solver"
    sudo mkdir -p $APP_DIR
    sudo chown $USER:$USER $APP_DIR
    
    # If running from existing directory, copy files
    if [[ -f "package.json" ]]; then
        log_info "Copying application files..."
        cp -r . $APP_DIR/
    else
        log_warning "No package.json found. Please manually clone your repository to $APP_DIR"
        log_info "You can run: git clone <your-repo-url> $APP_DIR"
        return
    fi
    
    cd $APP_DIR
    
    # Install npm dependencies
    log_info "Installing npm dependencies..."
    npm install
    
    log_success "Application setup completed in $APP_DIR"
}

# Interactive environment configuration
create_env_file() {
    log_info "Configuring environment variables..."
    
    APP_DIR="/opt/ai-math-solver"
    ENV_FILE="$APP_DIR/.env"
    
    echo
    echo "======================================"
    echo "  ENVIRONMENT CONFIGURATION SETUP"
    echo "======================================"
    echo
    
    # Database Configuration
    echo "📦 DATABASE CONFIGURATION"
    echo "Default database: postgresql://mathsolver:mathsolver123@localhost:5432/ai_math_solver"
    read -p "Enter your DATABASE_URL (or press Enter for default): " db_url
    if [[ -z "$db_url" ]]; then
        db_url="postgresql://mathsolver:mathsolver123@localhost:5432/ai_math_solver"
    fi
    echo "✓ Database URL set"
    echo
    
    # API Keys
    echo "🔑 API KEYS CONFIGURATION"
    echo "You need at least one AI service API key for the math solver to work."
    echo
    
    # Gemini API Key
    echo "Google Gemini AI API Key:"
    echo "Get your key from: https://makersuite.google.com/app/apikey"
    read -p "Enter your GEMINI_API_KEY (or press Enter to skip): " gemini_key
    if [[ -z "$gemini_key" ]]; then
        gemini_key="your_gemini_api_key_here"
        echo "⚠️  Gemini API key skipped - you can add it later"
    else
        echo "✓ Gemini API key configured"
    fi
    echo
    
    # OpenAI API Key
    echo "OpenAI ChatGPT API Key:"
    echo "Get your key from: https://platform.openai.com/api-keys"
    read -p "Enter your OPENAI_API_KEY (or press Enter to skip): " openai_key
    if [[ -z "$openai_key" ]]; then
        openai_key="your_openai_api_key_here"
        echo "⚠️  OpenAI API key skipped - you can add it later"
    else
        echo "✓ OpenAI API key configured"
    fi
    echo
    
    # Security Configuration
    echo "🔒 SECURITY CONFIGURATION"
    echo "Generating secure random secrets..."
    
    # Generate random secrets
    jwt_secret=$(openssl rand -hex 32)
    session_secret=$(openssl rand -hex 32)
    echo "✓ JWT and Session secrets generated"
    echo
    
    # Port Configuration
    echo "🌐 SERVER CONFIGURATION"
    read -p "Enter server PORT (default: 5000): " port
    if [[ -z "$port" ]]; then
        port="5000"
    fi
    echo "✓ Server port set to $port"
    echo
    
    # Summary
    echo "📋 CONFIGURATION SUMMARY"
    echo "Database: ${db_url}"
    echo "Gemini API: $([ "$gemini_key" != "your_gemini_api_key_here" ] && echo "✓ Configured" || echo "⚠️ Not configured")"
    echo "OpenAI API: $([ "$openai_key" != "your_openai_api_key_here" ] && echo "✓ Configured" || echo "⚠️ Not configured")"
    echo "Port: $port"
    echo "Security: ✓ Auto-generated secrets"
    echo
    
    read -p "Proceed with this configuration? (y/N): " confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        log_error "Configuration cancelled by user"
        exit 1
    fi
    
    # Create .env file with user inputs
    cat > $ENV_FILE <<EOF
# Database Configuration
DATABASE_URL=$db_url

# AI Service API Keys
GEMINI_API_KEY=$gemini_key
OPENAI_API_KEY=$openai_key

# Application Configuration
NODE_ENV=production
PORT=$port
VM_MODE=true

# Security (Auto-generated)
JWT_SECRET=$jwt_secret
SESSION_SECRET=$session_secret
EOF
    
    # Set appropriate permissions
    chmod 600 $ENV_FILE
    
    log_success "Environment file created at $ENV_FILE"
    
    # Check if API keys are missing
    if [[ "$gemini_key" == "your_gemini_api_key_here" && "$openai_key" == "your_openai_api_key_here" ]]; then
        echo
        log_warning "⚠️  NO API KEYS CONFIGURED!"
        echo "The application will not work without at least one AI service API key."
        echo "You can add them later by editing: $ENV_FILE"
        echo
        echo "To get API keys:"
        echo "• Gemini: https://makersuite.google.com/app/apikey"
        echo "• OpenAI: https://platform.openai.com/api-keys"
        echo
    else
        echo
        log_success "✅ Environment configuration completed successfully!"
        echo
    fi
}

# Setup database schema
setup_schema() {
    log_info "Setting up database schema..."
    
    APP_DIR="/opt/ai-math-solver"
    cd $APP_DIR
    
    # Load environment variables
    export $(cat .env | grep -v '^#' | xargs)
    
    # Push database schema
    npm run db:push
    
    log_success "Database schema created"
}

# Create systemd service
create_systemd_service() {
    log_info "Creating systemd service..."
    
    APP_DIR="/opt/ai-math-solver"
    SERVICE_FILE="/etc/systemd/system/ai-math-solver.service"
    
    sudo tee $SERVICE_FILE > /dev/null <<EOF
[Unit]
Description=AI Math Solver Application
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=VM_MODE=true
EnvironmentFile=$APP_DIR/.env
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=ai-math-solver

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd and enable service
    sudo systemctl daemon-reload
    sudo systemctl enable ai-math-solver
    
    log_success "Systemd service created and enabled"
}

# Configure Nginx reverse proxy
configure_nginx() {
    log_info "Configuring Nginx reverse proxy..."
    
    # Remove default site
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Create new site configuration
    sudo tee /etc/nginx/sites-available/ai-math-solver > /dev/null <<EOF
server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
}
EOF
    
    # Enable the site
    sudo ln -sf /etc/nginx/sites-available/ai-math-solver /etc/nginx/sites-enabled/
    
    # Test nginx configuration
    sudo nginx -t
    
    # Start and enable nginx
    sudo systemctl start nginx
    sudo systemctl enable nginx
    
    log_success "Nginx configured as reverse proxy"
}

# Configure firewall
configure_firewall() {
    log_info "Configuring firewall..."
    
    # Install and configure UFW
    sudo apt-get install -y ufw
    
    # Reset to defaults
    sudo ufw --force reset
    
    # Default policies
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    
    # Allow SSH, HTTP, and HTTPS
    sudo ufw allow ssh
    sudo ufw allow 80/tcp
    sudo ufw allow 443/tcp
    
    # Enable firewall
    sudo ufw --force enable
    
    log_success "Firewall configured"
}

# Create management scripts
create_management_scripts() {
    log_info "Creating management scripts..."
    
    APP_DIR="/opt/ai-math-solver"
    
    # Create start script
    sudo tee /usr/local/bin/ai-math-solver-start > /dev/null <<EOF
#!/bin/bash
sudo systemctl start ai-math-solver
sudo systemctl status ai-math-solver
EOF
    
    # Create stop script
    sudo tee /usr/local/bin/ai-math-solver-stop > /dev/null <<EOF
#!/bin/bash
sudo systemctl stop ai-math-solver
EOF
    
    # Create restart script
    sudo tee /usr/local/bin/ai-math-solver-restart > /dev/null <<EOF
#!/bin/bash
sudo systemctl restart ai-math-solver
sudo systemctl status ai-math-solver
EOF
    
    # Create logs script
    sudo tee /usr/local/bin/ai-math-solver-logs > /dev/null <<EOF
#!/bin/bash
sudo journalctl -u ai-math-solver -f
EOF
    
    # Create update script
    sudo tee /usr/local/bin/ai-math-solver-update > /dev/null <<EOF
#!/bin/bash
cd $APP_DIR
git pull
npm install
npm run build
sudo systemctl restart ai-math-solver
EOF
    
    # Make scripts executable
    sudo chmod +x /usr/local/bin/ai-math-solver-*
    
    log_success "Management scripts created in /usr/local/bin/"
}

# Display final instructions
show_final_instructions() {
    log_success "Installation completed successfully!"
    echo
    echo "🎉 AI Math Solver is now installed and configured!"
    echo
    log_info "Starting the application..."
    sudo systemctl start ai-math-solver
    sleep 3
    
    # Check if service started successfully
    if systemctl is-active --quiet ai-math-solver; then
        log_success "Application started successfully!"
        echo
        log_info "📱 Access your application:"
        echo "   🌐 Web: http://$(hostname -I | awk '{print $1}')"
        echo "   🏠 Local: http://localhost:5000"
        echo
        log_info "🔑 Admin Login:"
        echo "   📧 Email: admin@gmail.com"
        echo "   🔒 Password: admin25"
        echo
    else
        log_error "Failed to start application. Check logs:"
        echo "   sudo journalctl -u ai-math-solver -f"
        echo
    fi
    
    log_info "🛠️ Management Commands:"
    echo "   • ai-math-solver-start     # Start the application"
    echo "   • ai-math-solver-stop      # Stop the application"  
    echo "   • ai-math-solver-restart   # Restart the application"
    echo "   • ai-math-solver-logs      # View live logs"
    echo "   • ai-math-solver-update    # Update from repository"
    echo
    log_info "📁 Important Files:"
    echo "   • Configuration: /opt/ai-math-solver/.env"
    echo "   • Application: /opt/ai-math-solver/"
    echo "   • Service logs: sudo journalctl -u ai-math-solver"
    echo
    log_info "🆘 Need Help?"
    echo "   • Check VM_SETUP.md for troubleshooting"
    echo "   • View logs: ai-math-solver-logs"
    echo "   • Status check: sudo systemctl status ai-math-solver"
    echo
    log_warning "⚠️  Security Note: Change default admin password in production!"
}

# Main installation function
main() {
    echo "========================================"
    echo "  AI Math Solver - Automated Installer"
    echo "========================================"
    echo
    
    check_root
    check_os
    
    log_info "Starting installation process..."
    echo
    
    # Installation steps
    update_system
    install_dependencies
    install_nodejs
    install_postgresql
    setup_database
    setup_application
    create_env_file
    setup_schema
    create_systemd_service
    configure_nginx
    configure_firewall
    create_management_scripts
    
    echo
    show_final_instructions
}

# Run main function
main "$@"