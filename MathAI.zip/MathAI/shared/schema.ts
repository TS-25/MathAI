import { pgTable, text, serial, integer, boolean, timestamp, json, varchar, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }).default("user").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily usage tracking
export const dailyUsage = pgTable("daily_usage", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  date: date("date").notNull(),
  problemCount: integer("problem_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Announcements table
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  type: varchar("type", { length: 50 }).default("info").notNull(), // info, warning, success, error
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Math problems table (updated)
export const mathProblems = pgTable("math_problems", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  problem: text("problem").notNull(),
  language: text("language").notNull().default("english"),
  geminiSolution: json("gemini_solution"),
  chatgptSolution: json("chatgpt_solution"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  mathProblems: many(mathProblems),
  dailyUsage: many(dailyUsage),
}));

export const mathProblemsRelations = relations(mathProblems, ({ one }) => ({
  user: one(users, { fields: [mathProblems.userId], references: [users.id] }),
}));

export const dailyUsageRelations = relations(dailyUsage, ({ one }) => ({
  user: one(users, { fields: [dailyUsage.userId], references: [users.id] }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMathProblemSchema = createInsertSchema(mathProblems).pick({
  problem: true,
  language: true,
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const solveMathProblemSchema = z.object({
  problem: z.string().min(1, "Problem is required"),
  language: z.enum(["english", "bangla"]).default("english"),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
export type RegisterRequest = z.infer<typeof registerSchema>;
export type MathProblem = typeof mathProblems.$inferSelect;
export type InsertMathProblem = z.infer<typeof insertMathProblemSchema>;
export type SolveMathProblemRequest = z.infer<typeof solveMathProblemSchema>;
export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;
export type DailyUsage = typeof dailyUsage.$inferSelect;

export interface MathSolution {
  steps: Array<{
    title: string;
    description: string;
    equation?: string;
    type: "method" | "formula" | "calculation" | "solution";
  }>;
  finalAnswer: string;
  approach: string;
  explanation: string;
}

export interface AIResponse {
  solution: MathSolution;
  processingTime: number;
  model: string;
}
