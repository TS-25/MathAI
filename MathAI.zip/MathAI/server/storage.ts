import { 
  mathProblems, 
  users, 
  dailyUsage,
  announcements,
  type MathProblem, 
  type InsertMathProblem,
  type User,
  type InsertUser,
  type Announcement,
  type InsertAnnouncement,
  type DailyUsage
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, count, sum } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  getUser(id: number): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Math problem operations
  createMathProblem(problem: InsertMathProblem & { geminiSolution?: any; chatgptSolution?: any; userId?: number }): Promise<MathProblem>;
  getMathProblem(id: number): Promise<MathProblem | undefined>;
  getMathProblems(userId?: number): Promise<MathProblem[]>;
  
  // Daily usage operations
  getUserDailyUsage(userId: number, date: string): Promise<DailyUsage | undefined>;
  getDailyUsage(userId: number, date: string): Promise<DailyUsage | undefined>;
  incrementDailyUsage(userId: number, date: string): Promise<DailyUsage>;
  
  // Announcement operations
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  getActiveAnnouncements(): Promise<Announcement[]>;
  getAllAnnouncements(): Promise<Announcement[]>;
  updateAnnouncement(id: number, updates: Partial<Announcement>): Promise<Announcement | undefined>;
  deleteAnnouncement(id: number): Promise<void>;
  
  // Analytics
  getAnalytics(): Promise<{
    totalUsers: number;
    totalProblems: number;
    dailyProblems: number;
    activeUsers: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async createUser(userData: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.getUserById(id);
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Math problem operations
  async createMathProblem(insertProblem: InsertMathProblem & { geminiSolution?: any; chatgptSolution?: any; userId?: number }): Promise<MathProblem> {
    const [problem] = await db
      .insert(mathProblems)
      .values({
        problem: insertProblem.problem,
        language: insertProblem.language || "english",
        userId: insertProblem.userId || null,
        geminiSolution: insertProblem.geminiSolution || null,
        chatgptSolution: insertProblem.chatgptSolution || null,
      })
      .returning();
    return problem;
  }

  async getMathProblem(id: number): Promise<MathProblem | undefined> {
    const [problem] = await db.select().from(mathProblems).where(eq(mathProblems.id, id));
    return problem;
  }

  async getMathProblems(userId?: number): Promise<MathProblem[]> {
    if (userId) {
      return await db.select().from(mathProblems)
        .where(eq(mathProblems.userId, userId))
        .orderBy(desc(mathProblems.createdAt));
    }
    return await db.select().from(mathProblems).orderBy(desc(mathProblems.createdAt));
  }

  // Daily usage operations
  async getUserDailyUsage(userId: number, date: string): Promise<DailyUsage | undefined> {
    const [usage] = await db.select().from(dailyUsage)
      .where(and(eq(dailyUsage.userId, userId), eq(dailyUsage.date, date)));
    return usage;
  }

  async getDailyUsage(userId: number, date: string): Promise<DailyUsage | undefined> {
    return this.getUserDailyUsage(userId, date);
  }

  async incrementDailyUsage(userId: number, date: string): Promise<DailyUsage> {
    const existingUsage = await this.getUserDailyUsage(userId, date);
    
    if (existingUsage) {
      const [updated] = await db
        .update(dailyUsage)
        .set({ problemCount: existingUsage.problemCount + 1 })
        .where(eq(dailyUsage.id, existingUsage.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(dailyUsage)
        .values({
          userId,
          date,
          problemCount: 1,
        })
        .returning();
      return created;
    }
  }

  // Announcement operations
  async createAnnouncement(announcementData: InsertAnnouncement): Promise<Announcement> {
    const [announcement] = await db
      .insert(announcements)
      .values(announcementData)
      .returning();
    return announcement;
  }

  async getActiveAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements)
      .where(eq(announcements.isActive, true))
      .orderBy(desc(announcements.createdAt));
  }

  async getAllAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements).orderBy(desc(announcements.createdAt));
  }

  async updateAnnouncement(id: number, updates: Partial<Announcement>): Promise<Announcement | undefined> {
    const [announcement] = await db
      .update(announcements)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(announcements.id, id))
      .returning();
    return announcement;
  }

  async deleteAnnouncement(id: number): Promise<void> {
    await db.delete(announcements).where(eq(announcements.id, id));
  }

  // Analytics
  async getAnalytics(): Promise<{
    totalUsers: number;
    totalProblems: number;
    dailyProblems: number;
    activeUsers: number;
  }> {
    const today = new Date().toISOString().split('T')[0];
    
    const [totalUsersResult] = await db.select({ count: count() }).from(users);
    const [totalProblemsResult] = await db.select({ count: count() }).from(mathProblems);
    const [dailyProblemsResult] = await db.select({ count: count() }).from(mathProblems)
      .where(eq(mathProblems.createdAt, new Date(today)));
    const [activeUsersResult] = await db.select({ count: count() }).from(dailyUsage)
      .where(eq(dailyUsage.date, today));

    return {
      totalUsers: totalUsersResult.count,
      totalProblems: totalProblemsResult.count,
      dailyProblems: dailyProblemsResult.count,
      activeUsers: activeUsersResult.count,
    };
  }

  // Create default admin user if it doesn't exist
  async createDefaultAdmin(): Promise<void> {
    let retries = 3;
    while (retries > 0) {
      try {
        const adminEmail = 'admin@gmail.com';
        
        // Test database connection first
        console.log('Testing database connection...');
        await db.select().from(users).limit(1);
        console.log('Database connection successful');
        
        const existingAdmin = await this.getUserByEmail(adminEmail);
        
        if (!existingAdmin) {
          const hashedPassword = await bcrypt.hash('admin25', 10);
          await db.insert(users).values({
            email: adminEmail,
            password: hashedPassword,
            name: 'admin',
            role: 'admin',
            isActive: true,
          });
          console.log('✅ Default admin user created: admin@gmail.com / admin25');
        } else {
          console.log('✅ Default admin user already exists');
        }
        
        return; // Success, exit retry loop
      } catch (error) {
        retries--;
        console.error(`Error creating default admin (${3 - retries}/3):`, error);
        
        if (retries > 0) {
          console.log(`Retrying in 2 seconds... (${retries} retries left)`);
          await new Promise(resolve => setTimeout(resolve, 2000));
        } else {
          console.error('Failed to create default admin after 3 attempts');
          console.error('The application will continue but manual admin creation may be required');
        }
      }
    }
  }
}

export const storage = new DatabaseStorage();
