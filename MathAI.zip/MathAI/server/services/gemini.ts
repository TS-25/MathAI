import { GoogleGenAI } from "@google/genai";
import { MathSolution, AIResponse } from "@shared/schema";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function solveWithGemini(problem: string, language: string): Promise<AIResponse> {
  const startTime = Date.now();
  
  try {
    const prompt = language === 'bangla' 
      ? `আপনি একজন গণিত বিশেষজ্ঞ। নিম্নোক্ত গণিত সমস্যাটি ধাপে ধাপে সমাধান করুন এবং বাংলায় বিস্তারিত ব্যাখ্যা দিন। প্রতিটি ধাপের জন্য স্পষ্ট শিরোনাম এবং বিবরণ দিন।

সমস্যা: ${problem}

দয়া করে JSON ফরম্যাটে উত্তর দিন:
{
  "solution": {
    "steps": [
      {
        "title": "ধাপের শিরোনাম",
        "description": "ধাপের বিস্তারিত বিবরণ",
        "equation": "গাণিতিক সমীকরণ (যদি থাকে)",
        "type": "method|formula|calculation|solution"
      }
    ],
    "finalAnswer": "চূড়ান্ত উত্তর",
    "approach": "সমাধানের পদ্ধতি",
    "explanation": "সামগ্রিক ব্যাখ্যা"
  }
}`
      : `You are a mathematics expert. Solve the following math problem step by step with detailed explanations in English. Provide clear titles and descriptions for each step.

Problem: ${problem}

Please respond in JSON format:
{
  "solution": {
    "steps": [
      {
        "title": "Step title",
        "description": "Detailed step description",
        "equation": "Mathematical equation (if any)",
        "type": "method|formula|calculation|solution"
      }
    ],
    "finalAnswer": "Final answer",
    "approach": "Solution approach",
    "explanation": "Overall explanation"
  }
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            solution: {
              type: "object",
              properties: {
                steps: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      equation: { type: "string" },
                      type: { type: "string" }
                    },
                    required: ["title", "description", "type"]
                  }
                },
                finalAnswer: { type: "string" },
                approach: { type: "string" },
                explanation: { type: "string" }
              },
              required: ["steps", "finalAnswer", "approach", "explanation"]
            }
          },
          required: ["solution"]
        }
      },
      contents: prompt,
    });

    const processingTime = Date.now() - startTime;
    const result = JSON.parse(response.text);

    return {
      solution: result.solution,
      processingTime,
      model: "gemini-2.5-pro"
    };
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to solve with Gemini: " + (error instanceof Error ? error.message : "Unknown error"));
  }
}