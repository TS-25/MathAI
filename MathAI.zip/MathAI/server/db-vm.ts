// Alternative database configuration for VM environments
import { Client } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Parse the database URL for VM environments
const databaseUrl = process.env.DATABASE_URL;

// Create a regular PostgreSQL client for VM environments
export const client = new Client({
  connectionString: databaseUrl,
  ssl: databaseUrl.includes('localhost') ? false : { rejectUnauthorized: false },
  connectionTimeoutMillis: 10000,
  query_timeout: 30000,
});

// Connect the client
client.connect().catch(console.error);

export const db = drizzle({ client, schema });