import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import pkg from 'pg';
const { Client } = pkg;
import { drizzle as drizzleNodePg } from 'drizzle-orm/node-postgres';
import ws from "ws";
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

const databaseUrl = process.env.DATABASE_URL;
const isLocalOrVM = databaseUrl.includes('localhost') || databaseUrl.includes('127.0.0.1') || process.env.VM_MODE === 'true';

let db: any;
let pool: any;
let client: any;

if (isLocalOrVM) {
  // Use regular PostgreSQL client for VM/local environments
  console.log('Using PostgreSQL client for VM/local environment');
  client = new Client({
    connectionString: databaseUrl,
    ssl: databaseUrl.includes('localhost') ? false : { rejectUnauthorized: false },
    connectionTimeoutMillis: 10000,
    query_timeout: 30000,
  });
  
  // Connect with error handling
  client.connect().catch((error: any) => {
    console.error('PostgreSQL connection error:', error);
  });
  
  db = drizzleNodePg({ client, schema });
} else {
  // Use Neon serverless for cloud environments
  console.log('Using Neon serverless for cloud environment');
  neonConfig.webSocketConstructor = ws;
  neonConfig.useSecureWebSocket = true;
  neonConfig.pipelineConnect = true;

  pool = new Pool({ 
    connectionString: databaseUrl,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });

  db = drizzle({ client: pool, schema });
}

export { db, pool, client };