import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  solveMathProblemSchema, 
  loginSchema, 
  registerSchema,
  insertAnnouncementSchema
} from "@shared/schema";
import { solveWithGemini } from "./services/gemini";
import { solveWithOpenAI } from "./services/openai";
import { z } from "zod";
import { 
  authenticateToken, 
  requireAdmin, 
  generateToken, 
  comparePassword, 
  checkDailyLimit,
  type AuthenticatedRequest 
} from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // ===== PUBLIC ROUTES =====
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: "User already exists" });
      }
      
      const user = await storage.createUser(userData);
      const token = generateToken({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      });
      
      res.json({
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
        token,
      });
    } catch (error) {
      console.error("Register error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user || !user.isActive) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      const isValid = await comparePassword(password, user.password);
      if (!isValid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      const token = generateToken({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      });
      
      res.json({
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
        token,
      });
    } catch (error) {
      console.error("Login error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  // Get active announcements (public)
  app.get("/api/announcements", async (req, res) => {
    try {
      const announcements = await storage.getActiveAnnouncements();
      res.json(announcements);
    } catch (error) {
      console.error("Get announcements error:", error);
      res.status(500).json({ error: "Failed to fetch announcements" });
    }
  });

  // ===== AUTHENTICATED ROUTES =====
  
  // Get current user
  app.get("/api/auth/me", authenticateToken, async (req: AuthenticatedRequest, res) => {
    res.json({
      id: req.user!.id,
      name: req.user!.name,
      email: req.user!.email,
      role: req.user!.role,
    });
  });

  // Get user's daily usage
  app.get("/api/usage/daily", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const usage = await storage.getUserDailyUsage(req.user!.id, today);
      res.json({
        date: today,
        problemCount: usage?.problemCount || 0,
        limit: 10,
        remaining: Math.max(0, 10 - (usage?.problemCount || 0))
      });
    } catch (error) {
      console.error("Get usage error:", error);
      res.status(500).json({ error: "Failed to fetch usage" });
    }
  });

  // Solve math problem with both AI models (authenticated + daily limit)
  app.post("/api/solve", authenticateToken, checkDailyLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const { problem, language } = solveMathProblemSchema.parse(req.body);
      
      // Solve with both AI models concurrently
      const [geminiResponse, openaiResponse] = await Promise.allSettled([
        solveWithGemini(problem, language),
        solveWithOpenAI(problem, language)
      ]);

      const result = {
        problem,
        language,
        gemini: geminiResponse.status === "fulfilled" ? geminiResponse.value : {
          error: geminiResponse.reason?.message || "Failed to process with Gemini"
        },
        openai: openaiResponse.status === "fulfilled" ? openaiResponse.value : {
          error: openaiResponse.reason?.message || "Failed to process with OpenAI"
        }
      };

      // Save to storage and increment daily usage
      try {
        await storage.createMathProblem({
          problem,
          language,
          userId: req.user!.id,
          geminiSolution: geminiResponse.status === "fulfilled" ? geminiResponse.value : null,
          chatgptSolution: openaiResponse.status === "fulfilled" ? openaiResponse.value : null,
        });
        
        const today = new Date().toISOString().split('T')[0];
        await storage.incrementDailyUsage(req.user!.id, today);
      } catch (storageError) {
        console.error("Storage error:", storageError);
        // Continue even if storage fails
      }

      res.json(result);
    } catch (error) {
      console.error("Solve endpoint error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  // Get user's problem history
  app.get("/api/problems", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const problems = await storage.getMathProblems(req.user!.id);
      res.json(problems);
    } catch (error) {
      console.error("Get problems error:", error);
      res.status(500).json({ error: "Failed to fetch problems" });
    }
  });

  // Get specific problem
  app.get("/api/problems/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const problem = await storage.getMathProblem(id);
      if (!problem) {
        return res.status(404).json({ error: "Problem not found" });
      }
      
      // Check if user owns this problem or is admin
      if (problem.userId !== req.user!.id && req.user!.role !== 'admin') {
        return res.status(403).json({ error: "Access denied" });
      }
      
      res.json(problem);
    } catch (error) {
      console.error("Get problem error:", error);
      res.status(500).json({ error: "Failed to fetch problem" });
    }
  });

  // ===== ADMIN ROUTES =====
  
  // Get analytics
  app.get("/api/admin/analytics", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const analytics = await storage.getAnalytics();
      res.json(analytics);
    } catch (error) {
      console.error("Get analytics error:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  // Get all users
  app.get("/api/admin/users", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const users = await storage.getAllUsers();
      const safeUsers = users.map(user => ({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      }));
      res.json(safeUsers);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Get all problems (admin)
  app.get("/api/admin/problems", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const problems = await storage.getMathProblems();
      res.json(problems);
    } catch (error) {
      console.error("Get all problems error:", error);
      res.status(500).json({ error: "Failed to fetch problems" });
    }
  });

  // Update user status
  app.patch("/api/admin/users/:id", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isActive, role } = req.body;
      
      const user = await storage.updateUser(id, { isActive, role });
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isActive: user.isActive,
        updatedAt: user.updatedAt,
      });
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Get all announcements (admin)
  app.get("/api/admin/announcements", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const announcements = await storage.getAllAnnouncements();
      res.json(announcements);
    } catch (error) {
      console.error("Get all announcements error:", error);
      res.status(500).json({ error: "Failed to fetch announcements" });
    }
  });

  // Create announcement
  app.post("/api/admin/announcements", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const announcementData = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(announcementData);
      res.json(announcement);
    } catch (error) {
      console.error("Create announcement error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  // Update announcement
  app.patch("/api/admin/announcements/:id", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const announcement = await storage.updateAnnouncement(id, updates);
      if (!announcement) {
        return res.status(404).json({ error: "Announcement not found" });
      }
      
      res.json(announcement);
    } catch (error) {
      console.error("Update announcement error:", error);
      res.status(500).json({ error: "Failed to update announcement" });
    }
  });

  // Delete announcement
  app.delete("/api/admin/announcements/:id", authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteAnnouncement(id);
      res.json({ message: "Announcement deleted" });
    } catch (error) {
      console.error("Delete announcement error:", error);
      res.status(500).json({ error: "Failed to delete announcement" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
