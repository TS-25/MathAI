# AI Math Solver

An AI-powered math solver web application using Gemini and ChatGPT APIs with bilingual support for Bangla and English explanations.

## Features

- **Dual AI Processing**: Leverage both Google Gemini and OpenAI ChatGPT for comprehensive mathematical solutions
- **Bilingual Support**: Full support for English and Bengali languages
- **Step-by-Step Solutions**: Detailed mathematical explanations with LaTeX rendering
- **User Management**: Registration, login, and admin dashboard
- **Analytics Dashboard**: Track usage statistics and user activity
- **Announcements System**: Admin can create and manage announcements
- **Daily Usage Limits**: Track and manage user problem-solving limits

## Tech Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS + shadcn/ui components
- TanStack Query for state management
- Wouter for routing
- MathJax for LaTeX rendering

### Backend
- Node.js with Express.js
- TypeScript with ES modules
- PostgreSQL with Drizzle ORM
- JWT authentication
- RESTful API design

## Prerequisites

- Node.js 20 or higher
- PostgreSQL database
- Google Gemini API key
- OpenAI API key

## Database Setup

### Option 1: Using Replit (Recommended)

If you're running this on Replit, the database setup is automated:

1. The PostgreSQL module is already configured in `.replit`
2. Database tables are automatically created when you first run the app
3. A default admin user is created: `admin@gmail.com` / `admin25`

### Option 2: Local PostgreSQL Setup

1. **Install PostgreSQL**:
   ```bash
   # Ubuntu/Debian
   sudo apt-get install postgresql postgresql-contrib
   
   # macOS with Homebrew
   brew install postgresql
   
   # Windows
   # Download from https://www.postgresql.org/download/windows/
   ```

2. **Create Database**:
   ```bash
   # Connect to PostgreSQL
   sudo -u postgres psql
   
   # Create database and user
   CREATE DATABASE ai_math_solver;
   CREATE USER your_username WITH PASSWORD 'your_password';
   GRANT ALL PRIVILEGES ON DATABASE ai_math_solver TO your_username;
   \q
   ```

3. **Set Environment Variable**:
   ```bash
   export DATABASE_URL="postgresql://your_username:your_password@localhost:5432/ai_math_solver"
   ```

### Option 3: Using Neon (Cloud PostgreSQL)

1. Go to [Neon](https://neon.tech) and create a free account
2. Create a new project and database
3. Copy the connection string from the dashboard
4. Set the `DATABASE_URL` environment variable

## Installation & Setup

### Quick Install (Automated VM Setup)

For a fresh Ubuntu/Debian VM, use the automated installer:

```bash
# Download and run the installer
wget https://raw.githubusercontent.com/your-repo/ai-math-solver/main/install.sh
chmod +x install.sh
./install.sh
```

This script will automatically:
- Install Node.js 20, PostgreSQL, and all dependencies
- Set up the database and user accounts
- Configure Nginx reverse proxy and SSL
- Create systemd service for auto-start
- Set up firewall rules
- Create management scripts

### Manual Installation

1. **Clone and Install Dependencies**:
   ```bash
   git clone <repository-url>
   cd ai-math-solver
   npm install
   ```

2. **Environment Variables**:
   Create a `.env` file with the following variables:
   ```env
   DATABASE_URL=postgresql://username:password@localhost:5432/database_name
   GEMINI_API_KEY=your_gemini_api_key_here
   OPENAI_API_KEY=your_openai_api_key_here
   NODE_ENV=development
   PORT=5000
   ```

3. **Database Migration**:
   ```bash
   # Push schema to database (creates all tables)
   npm run db:push
   ```

4. **Start the Application**:
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm run build
   npm start
   ```

## API Keys Setup

### Google Gemini API Key

1. Go to [Google AI Studio](https://aistudio.google.com/)
2. Sign in with your Google account
3. Click "Get API key" and create a new API key
4. Copy the key and add it to your environment variables

### OpenAI API Key

1. Go to [OpenAI Platform](https://platform.openai.com/)
2. Sign up or sign in to your account
3. Navigate to API Keys section
4. Create a new secret key
5. Copy the key and add it to your environment variables

## Usage

### For Users

1. **Register**: Create a new account or use the demo admin account
2. **Solve Problems**: Enter mathematical problems in English or Bengali
3. **View Solutions**: Get step-by-step solutions from both AI models
4. **History**: View your previously solved problems

### For Administrators

1. **Login**: Use admin credentials (`admin@gmail.com` / `admin25`)
2. **Dashboard**: Access analytics and user management
3. **Announcements**: Create and manage system announcements
4. **User Management**: View and manage user accounts

## Database Schema

The application uses the following main tables:

- **users**: User accounts with authentication
- **math_problems**: Solved mathematical problems with AI solutions
- **daily_usage**: Daily usage tracking per user
- **announcements**: System announcements

## Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Push database schema changes
npm run db:push

# Type checking
npm run check
```

## Management Commands (After Automated Install)

```bash
# Application management
ai-math-solver-start      # Start the application
ai-math-solver-stop       # Stop the application  
ai-math-solver-restart    # Restart the application
ai-math-solver-logs       # View live logs
ai-math-solver-update     # Update from git repository

# System management
sudo systemctl status ai-math-solver    # Check service status
sudo systemctl enable ai-math-solver    # Enable auto-start
sudo systemctl disable ai-math-solver   # Disable auto-start
```

## Deployment

### Replit Deployment

1. Click the "Deploy" button in your Replit project
2. Configure domain and environment variables
3. Deploy with automatic scaling

### Manual Deployment

1. Set production environment variables
2. Build the application: `npm run build`
3. Start with: `npm start`
4. Ensure PostgreSQL database is accessible

## Troubleshooting

### Database Connection Issues

1. **Check DATABASE_URL**: Ensure the connection string is correct
2. **Network Access**: Verify database server is accessible
3. **Credentials**: Confirm username/password are correct
4. **Schema Migration**: Run `npm run db:push` to create tables

### API Key Issues

1. **Verify Keys**: Check that API keys are valid and active
2. **Quotas**: Ensure you haven't exceeded API usage limits
3. **Permissions**: Confirm API keys have necessary permissions

### Common Errors

- **"DATABASE_URL must be set"**: Add DATABASE_URL to environment variables
- **"Cannot connect to database"**: Check PostgreSQL service is running
- **"Invalid API key"**: Verify Gemini and OpenAI API keys are correct

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
1. Check the troubleshooting section above
2. Review the error logs in the console
3. Create an issue in the repository

---

**Note**: This application requires active API keys for Google Gemini and OpenAI services. Make sure to set up these services and obtain valid API keys before running the application.