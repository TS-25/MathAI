# VM Setup Guide for AI Math Solver

This guide helps you set up the AI Math Solver on a Virtual Machine (VM) or Ubuntu/Debian server.

## Quick Setup with install.sh

The automated install script handles everything for you:

```bash
# Download and run the automated installer
curl -fsSL https://your-app-url/install.sh -o install.sh
chmod +x install.sh
sudo ./install.sh
```

## VM-Specific Database Configuration

The application automatically detects VM environments and configures the database connection appropriately:

- **Cloud environments**: Uses Neon serverless with WebSocket connections
- **VM/Local environments**: Uses standard PostgreSQL client connections

### Environment Variables for VM

When running on a VM, set these environment variables:

```bash
export VM_MODE=true
export DATABASE_URL="your_postgresql_connection_string"
```

### Manual VM Setup

If you prefer manual setup:

1. **Install Dependencies**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib
```

2. **Setup Database**
```bash
# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql
CREATE DATABASE ai_math_solver;
CREATE USER math_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE ai_math_solver TO math_user;
\q
```

3. **Configure Application**
```bash
# Clone/copy your application
git clone your-repo-url /opt/ai-math-solver
cd /opt/ai-math-solver

# Install dependencies
npm install

# Set environment variables
export DATABASE_URL="postgresql://math_user:your_password@localhost:5432/ai_math_solver"
export VM_MODE=true

# Run database migrations
npm run db:push

# Start the application
npm run dev
```

## Troubleshooting

### WebSocket Connection Errors

If you see errors like:
```
connect ECONNREFUSED 127.0.0.1:443
```

This means the app is trying to use Neon's WebSocket connections. Fix this by:

1. Set `VM_MODE=true` environment variable
2. Use a local PostgreSQL database URL
3. Restart the application

### Database Connection Issues

For PostgreSQL connection problems:

1. **Check PostgreSQL is running**:
```bash
sudo systemctl status postgresql
```

2. **Test connection manually**:
```bash
psql "postgresql://math_user:your_password@localhost:5432/ai_math_solver"
```

3. **Check database URL format**:
```bash
# Correct format:
DATABASE_URL="postgresql://username:password@host:port/database"
```

### Port and Firewall

Make sure port 5000 is open:
```bash
sudo ufw allow 5000
```

Or if using nginx reverse proxy, ensure port 80/443 are open:
```bash
sudo ufw allow 80
sudo ufw allow 443
```

## Production Deployment

For production deployment on VM:

1. Use PM2 or systemd service
2. Set up nginx reverse proxy
3. Configure SSL with Let's Encrypt
4. Set proper environment variables
5. Use connection pooling for database

The automated installer (`install.sh`) handles all of this for you.

## Common VM Environment Variables

```bash
# Required
export DATABASE_URL="postgresql://username:password@localhost:5432/database"
export VM_MODE=true

# Optional API keys (for AI features)
export GEMINI_API_KEY="your_gemini_key"
export OPENAI_API_KEY="your_openai_key"

# Production settings
export NODE_ENV=production
export PORT=5000
```

## Support

If you encounter issues with VM setup:

1. Check the logs: `npm run dev` shows detailed error messages
2. Verify database connection
3. Ensure all environment variables are set
4. Check firewall and port settings